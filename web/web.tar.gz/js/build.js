// Run using
//
//    r.js -o build.js
//
// Keep this in sync with swish.js.  There must be another way to do this ...

({ baseURL: ".",
   
  waitSeconds: 60,			/* swish-min.js is big */
  paths:
  { jquery:      "../bower_components/jquery/dist/jquery.min",
    "jquery-ui": "../bower_components/jquery-ui/jquery-ui.min",
    laconic:     "../bower_components/laconic/laconic",
    bootstrap:   "../bower_components/bootstrap/dist/js/bootstrap.min",
    typeahead:   "../bower_components/typeahead.js/dist/typeahead.bundle.min",
    splitter:    "../bower_components/jquery.splitter/js/jquery.splitter-0.15.0",
    tagmanager:  "../bower_components/tagmanager/tagmanager",
    sha1:        "../bower_components/js-sha1/src/sha1",
    c3:          "../bower_components/c3/c3",
    d3:          "../bower_components/d3/d3",

					/* CodeMirror extensions */
    "tos_cm/mode/prolog": "codemirror/mode/prolog",
    "tos_cm/addon/hover/prolog-hover": "codemirror/addon/hover/prolog-hover",
    "tos_cm/addon/hover/text-hover": "codemirror/addon/hover/text-hover",
    "tos_cm/addon/hint/templates-hint": "codemirror/addon/hint/templates-hint",
    "tos_cm/addon/hint/show-context-info": "codemirror/addon/hint/show-context-info",

					/* Standard CodeMirror */
    "tos_cm" : "../bower_components/codemirror"
  },
  shim:
  { bootstrap:
    { deps:["jquery"]
    },
    typeahead:
    { deps:["jquery"]
    },
    splitter:
    { deps:["jquery"]
    },
    laconic:
    { deps:["jquery"]
    },
    tagmanager:
    { deps:["jquery"]
    }
  },

   name: "trill_on_swish",
   out: "trill_on_swish-min.js"
})
